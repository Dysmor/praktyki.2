import random

"""
**********************************************
Nazwa funkcji: wyszukaj_z_wartownikiem
Argumenty:     tablica - lista (tablica) wartości, wśród których należy
                          znaleźć daną wartość
               szukana_wartosc - wartość do znalezienia     
Typ zwracany:  int, jeśli element znaleziono, jest zwracany
               indeks pierwszego wystąpienia elementu na liście,
               jeśli elementu nie ma - zwracane jest -1.
Informacje:    Zaimplementowany algorytm to przeszukiwanie tablicy
               z wartownikiem. 
Autor:         000000000000
**********************************************
"""

def wypelnij_tablice(rozmiar: int, min_wartosc: int, max_wartosc: int) -> list[int]:
    return [random.randint(min_wartosc, max_wartosc) for _ in range(rozmiar)]
def wyszukaj_z_wartownikiem(tablica: list[int], szukana_wartosc: int) -> int:

    rozmiar = len(tablica)
    tablica.append(szukana_wartosc)
    indeks = 0

    while tablica[indeks] != szukana_wartosc:
        indeks += 1
    tablica.pop()
    return indeks if indeks < rozmiar else -1

def main():
    ROZMIAR_TABLICY = 50
    MIN_WARTOSC = 1
    MAX_WARTOSC = 100

    tablica = wypelnij_tablice(ROZMIAR_TABLICY, MIN_WARTOSC, MAX_WARTOSC)

    print("Wygenerowana tablica:")
    print(", ".join(map(str, tablica)))

    try:
        szukana_wartosc = int(input("Podaj liczbę do wyszukania: "))
    except ValueError:
        print("Błąd: Wprowadzona wartość nie jest liczbą całkowitą.")
        return

    indeks = wyszukaj_z_wartownikiem(tablica, szukana_wartosc)

    if indeks != -1:
        print(f"Wartość {szukana_wartosc} znaleziona na indeksie {indeks}.")
    else:
        print(f"Wartość {szukana_wartosc} nie występuje w tablicy.")

if __name__ == "__main__":
    main()