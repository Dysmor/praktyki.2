class Notatka:
    __liczba_notatek = 0

    def __init__(self, tytul: str, tresc: str):
        Notatka.__liczba_notatek += 1
        self.__id = Notatka.__liczba_notatek
        self._tytul = tytul
        self._tresc = tresc

    def wyswietl(self):
        print(f"Tytuł: {self._tytul}\nTreść: {self._tresc}\n")

    def diagnostyka(self):
        print(
            f"ID: {self.__id}; Tytuł: {self._tytul}; Treść: {self._tresc}; Licznik notatek: {Notatka.__liczba_notatek}")


if __name__ == '__main__':
    print("Witaj w programie do obsługi notatek!")

    tytul1 = input("Podaj tytuł pierwszej notatki: ")
    tresc1 = input("Podaj treść pierwszej notatki: ")

    tytul2 = input("Podaj tytuł drugiej notatki: ")
    tresc2 = input("Podaj treść drugiej notatki: ")


    notatka1 = Notatka(tytul1, tresc1)
    notatka2 = Notatka(tytul2, tresc2)


    print("\nPierwsza notatka:")
    notatka1.wyswietl()

    print("Druga notatka:")
    notatka2.wyswietl()

    print("Diagnostyka pierwszej notatki:")
    notatka1.diagnostyka()

    print("Diagnostyka drugiej notatki:")
    notatka2.diagnostyka()
