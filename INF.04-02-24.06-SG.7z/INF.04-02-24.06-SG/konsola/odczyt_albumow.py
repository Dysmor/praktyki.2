class Album:
    def __init__(self, artysta, album, liczba_utworow, rok_wydania, liczba_pobran):
        self.artysta = artysta
        self.album = album
        self.liczba_utworow = liczba_utworow
        self.rok_wydania = rok_wydania
        self.liczba_pobran = liczba_pobran

    def __str__(self):
        return (f"Artysta: {self.artysta}\n"
                f"Album: {self.album}\n"
                f"Liczba utworów: {self.liczba_utworow}\n"
                f"Rok wydania: {self.rok_wydania}\n"
                f"Pobrania: {self.liczba_pobran}\n")



def wczytaj_dane(nazwa_pliku):
    albumy = []
    try:
        with open(nazwa_pliku, encoding="utf-8") as plik:
            linie = [linia.strip() for linia in plik if linia.strip()]
            print(f"Liczba linii w pliku: {len(linie)}")
            for i in range(0, len(linie), 5):
                print(f"Wczytano album: {linie[i]}")
                artysta = linie[i]
                album = linie[i + 1].strip('"')
                liczba_utworow = int(linie[i + 2])
                rok_wydania = int(linie[i + 3])
                liczba_pobran = int(linie[i + 4])
                album = Album(artysta, album, liczba_utworow, rok_wydania, liczba_pobran)
                albumy.append(album)
        return albumy
    except FileNotFoundError:
        print(f"Plik {nazwa_pliku} nie został znaleziony.")
        return []
    except Exception as e:
        print(f"Wystąpił błąd: {e}")
        return []


def wyswietl_dane(albumy):
    if not albumy:
        print("Brak danych do wyświetlenia.")
        return
    for album in albumy:
        print(album)


if __name__ == "__main__":
    nazwa_pliku = "Data.txt"
    albumy = wczytaj_dane(nazwa_pliku)
    wyswietl_dane(albumy)
