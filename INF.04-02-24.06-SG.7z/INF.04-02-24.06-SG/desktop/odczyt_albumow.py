import tkinter as tk
from PIL import Image, ImageTk
class Album:
    def __init__(self, wykonawca, tytul, liczba_utworow, rok_wydania, liczba_pobran):
        self.wykonawca = wykonawca
        self.tytul = tytul
        self.liczba_utworow = liczba_utworow
        self.rok_wydania = rok_wydania
        self.liczba_pobran = liczba_pobran

def wczytaj_dane_z_pliku(nazwa_pliku):
    albumy = []
    try:
        with open(nazwa_pliku, "r", encoding="utf-8") as file:
            linie = file.readlines()
            for i in range(0, len(linie), 5):
                wykonawca = linie[i].strip()
                tytul = linie[i + 1].strip()

                try:
                    liczba_utworow = int(linie[i + 2].strip())
                    rok_wydania = int(linie[i + 3].strip())
                    liczba_pobran = int(linie[i + 4].strip())
                except ValueError:
                    print(f"Błąd w danych albumu {tytul}: Niepoprawne dane liczbowe.")
                    continue

                album = Album(wykonawca, tytul, liczba_utworow, rok_wydania, liczba_pobran)
                albumy.append(album)
        print(f"Wczytano {len(albumy)} albumów.")
    except Exception as e:
        print(f"Wystąpił błąd podczas wczytywania danych: {e}")
    return albumy

def wyswietl_album(album):
    print(f"Wyświetlanie albumu: {album.tytul}")
    wykonawca_label.config(text=f"Wykonawca: {album.wykonawca}")
    tytul_label.config(text=f"Tytuł: {album.tytul}")
    liczba_utworow_label.config(text=f"Liczba utworów: {album.liczba_utworow}")
    rok_wydania_label.config(text=f"Rok wydania: {album.rok_wydania}")
    liczba_pobran_label.config(text=f"Liczba pobrań: {album.liczba_pobran}")

def poprzedni_album():
    global aktualny_album
    print(f"Przed zmianą: {aktualny_album}")
    aktualny_album -= 1
    if aktualny_album < 0:
        aktualny_album = len(albumy) - 1
    print(f"Po zmianie: {aktualny_album}")
    wyswietl_album(albumy[aktualny_album])


def nastepny_album():
    global aktualny_album
    print(f"Przed zmianą: {aktualny_album}")
    aktualny_album += 1
    if aktualny_album >= len(albumy):
        aktualny_album = 0
    print(f"Po zmianie: {aktualny_album}")
    wyswietl_album(albumy[aktualny_album])

def pobierz_album():
    global albumy, aktualny_album
    albumy[aktualny_album].liczba_pobran += 1
    liczba_pobran_label.config(text=f"Liczba pobrań: {albumy[aktualny_album].liczba_pobran}")
    print(f"Pobrano album {albumy[aktualny_album].tytul} - Liczba pobrań: {albumy[aktualny_album].liczba_pobran}")



root = tk.Tk()
root.title("MojeDźwięki, Wykonał: 123456")
root.config(bg="#2E8B57")
root.geometry("600x400")

albumy = wczytaj_dane_z_pliku("Data.txt")
aktualny_album = 0

try:
    obraz2 = Image.open("obraz2.png").resize((70, 70), Image.Resampling.LANCZOS)
    obraz3 = Image.open("obraz3.png").resize((70, 70), Image.Resampling.LANCZOS)
    vinyl_image = Image.open("obraz.png").resize((200, 200), Image.Resampling.LANCZOS)
except FileNotFoundError:
    print("Nie znaleziono plików obrazów w katalogu!")

obraz2_tk = ImageTk.PhotoImage(obraz2)
obraz3_tk = ImageTk.PhotoImage(obraz3)
vinyl_image_tk = ImageTk.PhotoImage(vinyl_image)

wykonawca_label = tk.Label(root, text="", font=("Arial", 50), bg="#2E8B57", fg="white")
wykonawca_label.pack()

tytul_label = tk.Label(root, text="", font=("Arial", 30, "italic"), bg="#2E8B57", fg="#61D918")
tytul_label.pack()

liczba_utworow_label = tk.Label(root, text="", font=("Arial", 20), bg="#2E8B57", fg="white")
liczba_utworow_label.pack()

rok_wydania_label = tk.Label(root, text="", font=("Arial", 20), bg="#2E8B57", fg="white")
rok_wydania_label.pack()

liczba_pobran_label = tk.Label(root, text="", font=("Arial", 20), bg="#2E8B57", fg="white")
liczba_pobran_label.pack()

vinyl_label = tk.Label(root, image=vinyl_image_tk, bg="#2E8B57")
vinyl_label.pack()

pobierz_button = tk.Button(root, text="Pobierz", font=("Arial", 20, "bold"), bg="#61D918", command=pobierz_album)
pobierz_button.pack()

poprzedni_button = tk.Button(root, image=obraz2_tk, bg="#2E8B57", command=poprzedni_album)
poprzedni_button.pack(side="left", padx=20)

nastepny_button = tk.Button(root, image=obraz3_tk, bg="#2E8B57", command=nastepny_album)
nastepny_button.pack(side="right", padx=20)

if albumy:
    wyswietl_album(albumy[aktualny_album])
else:
    print("Brak albumów w pliku.")

root.mainloop()
