"""
*****************************************
nazwa funkcji:       nwd
opis funkcji:        Funkcja oblicza największy wspólny dzielnik dwóch
                     liczb całkowitych dodatnich za pomocą algorytmu Euklidesa.
parametry:           a - pierwsza liczba całkowita dodatnia
                     b - druga liczba całkowita dodatnia
zwracany typ i opis: int - liczba całkowita która jest największym wspólnym dzielnikiem
                     liczby a oraz b.
autor:               00000000000000000
*****************************************
"""
def nwd(a: int, b: int) -> int:

    while a != b:
        if a > b:
            a -= b
        else:
            b -= a
    return a


def main():

    while True:
        try:
            a = int(input("Podaj pierwszą liczbę całkowitą dodatnią (a): "))
            b = int(input("Podaj drugą liczbę całkowitą dodatnią (b): "))

            if a <= 0 or b <= 0:
                print("Obie liczby muszą być całkowite i dodatnie. Spróbuj ponownie.")
                continue

            wynik = nwd(a, b)
            print(f"Największy wspólny dzielnik (NWD) liczb {a} i {b} to: {wynik}")
            break

        except ValueError:
            print("Podano nieprawidłowe dane. Upewnij się, że wprowadzasz liczby całkowite.")


if __name__ == "__main__":
    main()