def sprawdz_plec(pesel):

    cyfra_plec = int(pesel[9])
    if cyfra_plec % 2 == 0:
        return "Kobieta"
    else:
        return "Mężczyzna"


def sprawdz_sume_kontrolna(pesel):
    wagi = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3]
    suma = 0


    for i in range(10):
        suma += int(pesel[i]) * wagi[i]

    modulo = suma % 10
    if modulo == 0:
        suma_kontrolna = 0
    else:
        suma_kontrolna = 10 - modulo

    return suma_kontrolna == int(pesel[10])


def main():
    pesel = input("Podaj numer PESEL (11 cyfr): ").strip()

    if len(pesel) != 11 or not pesel.isdigit():
        print("Błąd: Numer PESEL musi zawierać 11 cyfr.")
        return

    plec = sprawdz_plec(pesel)
    print(f"Płeć: {plec}")

    if sprawdz_sume_kontrolna(pesel):
        print("Suma kontrolna jest poprawna.")
    else:
        print("Suma kontrolna jest niepoprawna.")


if __name__ == "__main__":
    main()
