import math

"""
*********************************************************
  nazwa funkcji:       wypelnienie
  parametry wejściowe: tablica - lista wartości logicznych, n - liczba całkowita określająca górną granicę przedziału
  wartość zwracana:    brak 
  opis:                Funkcja rozpoczyna tablicę, ustawiając wszystkie elementy od 2 do n na wartość True, 
                       dzięki czemu przygotowywuje do działania algorytmu sita Eratostenesa.
  autor:               0000000000000000
*********************************************************
"""




def wypelnienie(tablica: list, n: int) -> None:

    for i in range(2, n + 1):
        tablica[i] = True


def sito(tablica: list, n: int) -> None:

    for i in range(2, int(math.sqrt(n)) + 1):
        if tablica[i]:
            for j in range(i * i, n + 1, i):
                tablica[j] = False


if __name__ == '__main__':
    n = 100
    tablica = [None] * (n + 1)

    wypelnienie(tablica, n)

    sito(tablica, n)

    print(f"Liczby pierwsze w przedziale 2..{n}: ", end='')
    for i in range(2, n + 1):
        if tablica[i]:
            print(i, end=' ')
