import sys
from PyQt5 import QtWidgets, uic
from PyQt5.QtGui import QPixmap

class ParcelApp(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('okno.ui', self)
        self.initialize_ui()
        self.show()

    def initialize_ui(self):
        self.button_check_price = self.findChild(QtWidgets.QPushButton, 'pushButton_check_price')
        self.button_check_price.clicked.connect(self.display_price)

        self.button_apply = self.findChild(QtWidgets.QPushButton, 'pushButton_apply')
        self.button_apply.clicked.connect(self.validate_address)

        self.groupbox_parcel_type = self.findChild(QtWidgets.QButtonGroup, 'buttonGroup_parcel_type')


        self.input_street = self.findChild(QtWidgets.QLineEdit, 'lineEdit_street')
        self.input_postal_code = self.findChild(QtWidgets.QLineEdit, 'lineEdit_postal_code')
        self.input_city = self.findChild(QtWidgets.QLineEdit, 'lineEdit_city')


        self.label_img = self.findChild(QtWidgets.QLabel, 'label_img')
        self.label_price = self.findChild(QtWidgets.QLabel, 'label_price')

    def display_price(self):

        parcel_data = {
            -2: ("1 zł", "pocztowka.png"),
            -3: ("1,5 zł", "list.png"),
            -4: ("10 zł", "paczka.png")
        }

        selected_parcel_id = self.groupbox_parcel_type.checkedId()
        if selected_parcel_id in parcel_data:
            price, image = parcel_data[selected_parcel_id]
            self.label_price.setText(f"Cena: {price}")
            self.label_img.setPixmap(QPixmap(f"images/{image}"))
        else:
            self.label_price.setText("Nie wybrano rodzaju przesyłki")
            self.label_img.clear()

    def validate_address(self):
        postal_code = self.input_postal_code.text()
        message = self.get_postal_code_validation_message(postal_code)

        msgbox = QtWidgets.QMessageBox()
        msgbox.setText(message)
        msgbox.setWindowTitle("Informacja")
        msgbox.exec_()

    @staticmethod
    def get_postal_code_validation_message(postal_code):

        if len(postal_code) != 5:
            return "Nieprawidłowa liczba cyfr w kodzie pocztowym"
        elif not postal_code.isnumeric():
            return "Kod pocztowy powinien się składać z samych cyfr"
        return "Dane przesyłki zostały wprowadzone"

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = ParcelApp()
    app.exec_()